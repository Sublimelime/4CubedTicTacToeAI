/* LocationInt - Is and interface for what a location
 * must store */
public interface LocationInt 
{
	/* Pre:		None
	 * Post: 	returns the sheet (z) of the location */
	public int getSheet();

	/* Pre:		None
	 * Post: 	returns the row (y) of the location */
	public int getRow();

	/* Pre:		None
	 * Post: 	returns the column (x) of the location */
	public int getCol();

	/* Pre:		None
	 * Post: 	returns a text representation of the location */
	public String toString();
}
