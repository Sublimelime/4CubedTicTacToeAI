/* BoardInt - Is an Interface for for what a 3d 4x4x4
 * should be able to do */
import java.awt.Graphics;
import java.util.*;

public interface BoardInt
{
	/* Pre: Receives a location and letter (in the form of 'X' or 'O')
	 * Post: when the provided location is empty ('-') it places the 
	 * received letter into the location and returns true, otherwise
	 * it returns false*/
	public boolean setLocation(LocationInt l, char c);
	
	/* Pre: Receives a location and letter (in the form of 'X' or 'O')
	 * Post: it places the received letter into the location */
	public void setLocationNoCheck(LocationInt l, char c);

	/* Pre: Receives a location 
	 * Post: returns the letter at the provided location */
	public char getLocation(LocationInt l);

	/* Pre: Receives a player's letter 
	 * Post: returns if the received letter has a win one the board */
	public boolean isWinner(char c);

	/* Pre: None
	 * Post: draws a text representation of the game board */
	public void display();

	/* Pre: Recieves a graphics object
	 * Post: draws a graphical representation of the board to the received
	 * graphics object */
	public void draw(Graphics g);

	/* Pre: None
	 * Post: returns a 3D char array that stores the boards data*/
	public char[][][] getData();

	/* Pre: Receives a location
	 * Post: returns true if the provided location is empty ('-'),
	 * otherwise it returns false*/
	public boolean isEmpty(LocationInt l);

	/* Pre: None
	 * Post: returns true there is no winner and all the spaces
	 * are filled*/
	public boolean isCat();

	/* Pre: None
	 * Post: returns the number of sheets on the board*/
	public int numSheets();

	/* Pre: None
	 * Post: returns the number of rows on the board*/
	public int numRows();

	/* Pre: None
	 * Post: returns the number of columns on the board*/
	public int numCols();

	/* Pre: None
	 * Post: sets all the locations on the board to empty ('-')*/
	public void reset();
	
	/* Pre: None
	 * Post: Returns an ArrayList of GamePolygons for each location
	 * on the board*/
	public ArrayList<GamePolygon> getPolys();
}
